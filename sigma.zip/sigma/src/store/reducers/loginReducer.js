import axios from "axios";
import * as ActionTypes from "../actionTypes";
const initialStateLogin = {
  hasError: false,
  errorMessage: "",
  loginForm: {
    email: {
      type: "email",
      value: "",
      validation: {
        required: true,
        isEmail: true
      },
      valid: false,
      touched: false
    },
    password: {
      type: "password",
      value: "",
      validation: {
        required: true
      },
      valid: false,
      touched: false
    }
  }
};
const checkValidity = (value, rules) => {
  let isValid = true;
  if (rules.required) {
    isValid = value.trim().length > 0 && isValid;
  }
  if (rules.isEmail) {
    isValid = /^[a-zA-Z0-9]+@[a-zA-Z0-9]+\.[A-Za-z]+$/.test(value) && isValid;
  }
  // if (rules.minLength) {
  //   isValid = value.length >= rules.minLength && isValid;
  // }
  // if (rules.maxLength) {
  //   isValid = value.length <= rules.maxLength && isValid;
  // }
  return isValid;
};
const loginReducer = (state = initialStateLogin, action) => {
  switch (action.type) {
    case ActionTypes.LOGIN_INPUT_CHANGED_HANDLER:
      const loginForm = {
        ...state.loginForm
      };
      const updatedFormElement = {
        ...loginForm[action.inputIdentifier]
      };
      updatedFormElement.value = action.event.target.value;
      updatedFormElement.valid = checkValidity(
        updatedFormElement.value,
        updatedFormElement.validation
      );
      updatedFormElement.touched = true;
      loginForm[action.inputIdentifier] = updatedFormElement;
      break;
    case ActionTypes.LOGIN_SUBMIT:
      action.e.preventDefault();
      const form = {
        ...state.loginForm
      };
      let loginObj = {};
      for (let key in form) {
        loginObj[key] = loginForm[key].value;
      }
      loginObj["user_type"] = "admin";
      axios.post("login", loginObj).then(result => {
        if (result.data.code === 200) {
          localStorage.setItem("jwtToken", result.data.token);
          this.props.history.push("/admin/dashboard");
        } else {
          state = { ...state, errorMessage: result.data.message };
        }
      });
      break;
  }
  return state;
};
export default loginReducer;
