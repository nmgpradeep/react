import * as ActionTypes from "../actionTypes";
const initialState = {
  layoutMode: "static",
  layoutColorMode: "dark",
  staticMenuInactive: false,
  overlayMenuActive: false,
  mobileMenuActive: false,
  isAuthenticated: false
};
const appReducer = (state = initialState, action) => {
  switch (action.type) {
    case ActionTypes.APP_WRAPPER_CLICK:
      state = { ...state, overlayMenuActive: false, mobileMenuActive: false };
      break;
  }
  return state;
};
export default appReducer;
