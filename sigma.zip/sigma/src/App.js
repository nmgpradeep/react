import React, { Component } from "react";
import { connect } from "react-redux";
import classNames from "classnames";
import { AppTopbar } from "./AppTopbar";
import { AppFooter } from "./AppFooter";
import { AppMenu } from "./AppMenu";
import { AppInlineProfile } from "./AppInlineProfile";
import { /*BrowserRouter as Router,*/ Route, Redirect } from "react-router-dom";
import { Dashboard } from "./containers/Dashboard/Dashboard";
import { Login } from "./containers/Login/Login";
import { ForgotPassword } from "./containers/ForgotPassword/ForgotPassword";
import Logout from "./components/Logout/Logout";
import { ScrollPanel } from "primereact/components/scrollpanel/ScrollPanel";
import Menu from "./config/constant";
import Aux from "./hoc/Auxiliary";
import * as ActionTypes from "./store/actionTypes";
import "primereact/resources/themes/nova-light/theme.css";
import "primereact/resources/primereact.min.css";
import "primeicons/primeicons.css";
import "primeflex/primeflex.css";
import "fullcalendar/dist/fullcalendar.css";
import "./layout/layout.css";
import "./App.css";
import axios from "axios";
////{"email":"rahul.mehta.newmediaguru@gmail.com","password":"1234567"}
const port = 5000;
axios.defaults.baseURL =
  window.location.protocol + "//" + window.location.hostname + ":" + port;
//axios.defaults.baseURL = window.location.protocol + "//node.newmediaguru.co:" + port;
axios.defaults.headers.post["Content-Type"] = "application/json";
axios.defaults.headers.common["Authorization"] = localStorage.getItem(
  "jwtToken"
);
class App extends Component {
  constructor(props) {
    super(props);
    //this.store = this.props;
    console.log("APP Props", this.props);
    this.onToggleMenu = this.onToggleMenu.bind(this);
    this.onSidebarClick = this.onSidebarClick.bind(this);
    this.onMenuItemClick = this.onMenuItemClick.bind(this);
    this.createMenu();
  }
  componentDidMount() {
    if (
      !this.props.isAuthenticated &&
      localStorage.getItem("jwtToken") != null
    ) {
      this.setState({ isAuthenticated: true });
    }
  }
  // onWrapperClick(event) {
  //   if (!this.menuClick) {
  //     this.setState({
  //       overlayMenuActive: false,
  //       mobileMenuActive: false
  //     });
  //   }
  //
  //   this.menuClick = false;
  // }

  onToggleMenu(event) {
    this.menuClick = true;

    if (this.isDesktop()) {
      if (this.props.layoutMode === "overlay") {
        this.setState({
          overlayMenuActive: !this.props.overlayMenuActive
        });
      } else if (this.props.layoutMode === "static") {
        this.setState({
          staticMenuInactive: !this.props.staticMenuInactive
        });
      }
    } else {
      const mobileMenuActive = this.props.mobileMenuActive;
      this.setState({
        mobileMenuActive: !mobileMenuActive
      });
    }

    event.preventDefault();
  }

  onSidebarClick(event) {
    this.menuClick = true;
    setTimeout(() => {
      this.layoutMenuScroller.moveBar();
    }, 500);
  }

  onMenuItemClick(event) {
    if (!event.item.items) {
      this.setState({
        overlayMenuActive: false,
        mobileMenuActive: false
      });
    }
  }

  createMenu() {
    this.menu = [...Menu.Menu];
  }

  addClass(element, className) {
    if (element.classList) element.classList.add(className);
    else element.className += " " + className;
  }

  removeClass(element, className) {
    if (element.classList) element.classList.remove(className);
    else
      element.className = element.className.replace(
        new RegExp(
          "(^|\\b)" + className.split(" ").join("|") + "(\\b|$)",
          "gi"
        ),
        " "
      );
  }

  isDesktop() {
    return window.innerWidth > 1024;
  }

  componentDidUpdate() {
    if (this.props.mobileMenuActive)
      this.addClass(document.body, "body-overflow-hidden");
    else this.removeClass(document.body, "body-overflow-hidden");
  }

  render() {
    let logo =
      this.props.layoutColorMode === "dark"
        ? "assets/layout/images/logo-white.svg"
        : "assets/layout/images/logo.svg";

    let wrapperClass = classNames("layout-wrapper", {
      "layout-overlay": this.props.layoutMode === "overlay",
      "layout-static": this.props.layoutMode === "static",
      "layout-static-sidebar-inactive":
        this.props.staticMenuInactive && this.props.layoutMode === "static",
      "layout-overlay-sidebar-active":
        this.props.overlayMenuActive && this.props.layoutMode === "overlay",
      "layout-mobile-sidebar-active": this.props.mobileMenuActive
    });
    let sidebarClassName = classNames("layout-sidebar", {
      "layout-sidebar-dark": this.props.layoutColorMode === "dark"
    });
    let layout = null;
    const PATHNAME = "/login";
    if (!this.props.isAuthenticated) {
      let redirect = null;
      if (
        window.location.pathname !== "/forgot-password" ||
        window.location.pathname !== PATHNAME
      )
        redirect = (
          <Redirect
            to={{
              pathname: PATHNAME
            }}
          />
        );
      layout = (
        <div className="login-box">
          <Route
            path={PATHNAME}
            exact
            render={props => (
              <Login {...props} loginReducer={this.props.loginReducer} />
            )}
          />
          <Route path="/forgot-password" exact component={ForgotPassword} />
          {window.location.pathname !== "/forgot-password" ? redirect : null}
        </div>
      );
    } else {
      layout = (
        <div className={wrapperClass} onClick={this.props.onWrapperClick}>
          <AppTopbar onToggleMenu={this.onToggleMenu} />

          <div
            ref={el => (this.sidebar = el)}
            className={sidebarClassName}
            onClick={this.onSidebarClick}
          >
            <ScrollPanel
              ref={el => (this.layoutMenuScroller = el)}
              style={{ height: "100%" }}
            >
              <div className="layout-sidebar-scroll-content">
                <div className="layout-logo">
                  <img alt="Logo" src={logo} />
                </div>
                <AppInlineProfile />
                <AppMenu
                  model={this.menu}
                  onMenuItemClick={this.onMenuItemClick}
                />
              </div>
            </ScrollPanel>
          </div>

          <div className="layout-main">
            <Route path="/admin/dashboard" exact component={Dashboard} />
            <Route path="/admin/logout" component={Logout} />
            <Route path="/login" exact component={Login} />
          </div>

          <AppFooter />

          <div className="layout-mask" />
        </div>
      );
    }

    return <Aux>{layout}</Aux>;
  }
}
const mapStateToProps = state => {
  console.log("App mapStateToProps", state);
  return {
    layoutMode: state.appReducer.layoutMode,
    layoutColorMode: state.appReducer.layoutColorMode,
    staticMenuInactive: state.appReducer.staticMenuInactive,
    overlayMenuActive: state.appReducer.overlayMenuActive,
    mobileMenuActive: state.appReducer.overlayMenuActive,
    isAuthenticated: state.appReducer.isAuthenticated,
    loginReducer: state.loginReducer
    //store:
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onWrapperClick: e =>
      dispatch({
        type: ActionTypes.APP_WRAPPER_CLICK,
        payload: {
          event: e
        }
      })
  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(App);
