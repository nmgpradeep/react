import React, { Component } from "react";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import { InputText } from "primereact/inputtext";
import { Password } from "primereact/password";
import { Button } from "primereact/button";
import * as ActionTypes from "../../store/actionTypes";
export class Login extends Component {
  constructor(props) {
    super(props);
    console.log("Loging props", props);
  }
  render() {
    const formElementsArray = [];
    let errorBox = null;
    console.log("Login Form props", this.props);
    for (let key in this.props.loginForm) {
      formElementsArray.push({
        id: key,
        config: this.props.loginForm[key]
      });
    }
    if (this.props.hasError) {
      errorBox = (
        <div className="has-error">
          {this.props.errorMessage}
          <i>X</i>
        </div>
      );
    }
    return (
      <div className="p-grid p-fluid">
        <div className="p-col-12 p-lg-12 p-md-12">
          <div className="card card-w-title">
            <h1>Login</h1>
            <form className="p-grid" onSubmit={this.props.handleSubmit}>
              <div className="p-col-12 p-md-12">
                <p className="p-error">{errorBox}</p>
              </div>
              {formElementsArray.map(formElement => {
                if (formElement.config.type === "email") {
                  return (
                    <div className="p-col-12" key={formElement.id}>
                      <label htmlFor="acUsername">Username</label>
                      <InputText
                        value={formElement.value}
                        onChange={event =>
                          this.props.inputChangedHandler(event, "email")
                        }
                        keyfilter="email"
                      />
                    </div>
                  );
                } else {
                  return (
                    <div className="p-col-12" key={formElement.id}>
                      <label htmlFor="acPassword">Password</label>
                      <Password
                        value={formElement.value}
                        onChange={event =>
                          this.props.inputChangedHandler(event, "password")
                        }
                      />
                    </div>
                  );
                }
              })}
              <div className="p-col-12">
                <Button label="Login" />
                <Link to="/forgot-password">Forgot Password</Link>
              </div>
            </form>
          </div>
        </div>
      </div>
    );
  }
}
const mapStateToProps = (state, ownProps) => {
  console.log("Login mapStateToProps", state, ownProps);
  return {
    hasError: state.loginReducer.hasError,
    errorMessage: state.loginReducer.errorMessage,
    loginForm: state.loginReducer.loginForm
  };
};

const mapDispatchToProps = dispatch => {
  return {
    handleSubmit: e =>
      dispatch({
        type: ActionTypes.LOGIN_SUBMIT,
        payload: {
          event: e
        }
      }),
    inputChangedHandler: e =>
      dispatch({
        type: ActionTypes.LOGIN_INPUT_CHANGED_HANDLER,
        payload: {
          event: e
        }
      })
  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Login);
