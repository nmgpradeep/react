import React, { Component } from "react";
import { Link } from "react-router-dom";
import { InputText } from "primereact/inputtext";
import { Button } from "primereact/button";
import { Messages } from "primereact/messages";
import axios from "axios";

export class ForgotPassword extends Component {
  constructor(props) {
    super(props);
    this.state = {
      hasError: false,
      errorMessage: "",
      ForgotPasswordForm: {
        email: {
          type: "email",
          value: "",
          validation: {
            required: true,
            isEmail: true
          },
          valid: false,
          touched: false
        }
      },
      message: ""
    };
  }

  checkValidity(value, rules) {
    let isValid = true;
    if (rules.required) {
      isValid = value.trim().length > 0 && isValid;
    }
    if (rules.isEmail) {
      isValid = /^[a-zA-Z0-9]+@[a-zA-Z0-9]+\.[A-Za-z]+$/.test(value) && isValid;
    }
    // if (rules.minLength) {
    //   isValid = value.length >= rules.minLength && isValid;
    // }
    // if (rules.maxLength) {
    //   isValid = value.length <= rules.maxLength && isValid;
    // }
    return isValid;
  }
  inputChangedHandler = (event, inputIdentifier) => {
    const forgotPasswordForm = {
      ...this.state.ForgotPasswordForm
    };
    const updatedFormElement = {
      ...forgotPasswordForm[inputIdentifier]
    };
    updatedFormElement.value = event.target.value;
    updatedFormElement.valid = this.checkValidity(
      updatedFormElement.value,
      updatedFormElement.validation
    );
    console.log("Validation", updatedFormElement.valid);
    updatedFormElement.touched = true;
    forgotPasswordForm[inputIdentifier] = updatedFormElement;
    this.setState({
      ForgotPasswordForm: forgotPasswordForm,
      hasError: false,
      errorMessage: ""
    });
  };
  handleSubmit = e => {
    e.preventDefault();
    const forgotPasswordForm = {
      ...this.state.ForgotPasswordForm
    };
    let forgotPasswordFormObj = {};
    let isValid = false;
    for (let key in forgotPasswordForm) {
      if (forgotPasswordForm[key].valid)
        isValid = forgotPasswordForm[key].valid;
      forgotPasswordFormObj[key] = forgotPasswordForm[key].value;
    }
    forgotPasswordFormObj["user_type"] = "admin";
    if (isValid) {
      axios.post("forgot-password", forgotPasswordFormObj).then(result => {
        if (result.data.code === 200) {
          this.props.history.push("/login");
        } else {
          this.messages.show({
            severity: "error",
            summary: result.data.message,
            detail: ""
          });
          this.setState({ message: result.data.message });
        }
      });
    } else {
      this.setState({ hasError: true }, () => {
        this.messages.show({
          severity: "error",
          summary: "Invalid Email",
          detail: "Validation failed"
        });
      });
    }
  };

  render() {
    let errorBox = <Messages ref={el => (this.messages = el)} />;
    return (
      <div className="p-grid p-fluid">
        <div className="p-col-12 p-lg-12 p-md-12">
          <div className="card card-w-title">
            <h1>Forgot Password</h1>
            <form className="p-grid" onSubmit={this.handleSubmit}>
              <div className="p-col-12 p-md-12">{errorBox}</div>
              <div className="p-col-12">
                <label htmlFor="acUsername">Email</label>
                <InputText
                  value={this.state.ForgotPasswordForm.email.value}
                  onChange={event => this.inputChangedHandler(event, "email")}
                  keyfilter="email"
                />
              </div>
              <div className="p-col-12">
                <Button label="Submit" />
                <Link to="/login">Login</Link>
              </div>
            </form>
          </div>
        </div>
      </div>
    );
  }
}
