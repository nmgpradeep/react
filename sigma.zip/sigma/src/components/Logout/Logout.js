const Logout = props => {
  alert("here");
  localStorage.removeItem("jwtToken");
  props.history.push("/login");
  return null;
};
export default Logout;
