<?php



//******************************
//********CONFIGURATION*********
//******************************

$CHROME_URL = "chrm";
$SAFARI_URL = "sfr";
$OTHER_URL = "main";

//******************************
//******************************

// Redirection code
$HTTP_USER_AGENT = $_SERVER['HTTP_USER_AGENT'];

function str_present($str,$substr)
{
$pos = strpos($str,$substr);

if($pos === false) {
 return false;
}
else {
 return true;
}
}



if (str_present($HTTP_USER_AGENT, "Chrome"))
{
	Header ("Location: " . $CHROME_URL);
}

else if (str_present($HTTP_USER_AGENT, "Safari"))
{
	Header ("Location: " . $SAFARI_URL);
}

else
{
	Header ("Location: " . $OTHER_URL);
}

?>